#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# _authors_: Vozec

def searchuser(username):
	res = [username]
	return 'Soon ...'
	#return res #username


def searchemail(mail):
	res = [mail]
	return 'Soon ...'
	#return res #mail


def searchphone(phone):
	res = [phone]
	return 'Soon ...'
	#return res #phone

def searchimage(image):
	res = [image]
	return 'Soon ...'
	#return  res #phone